var loadModel = require('../models/events');

exports.createEvent = function (req, res) {
        loadModel.create(req.body, function (err, data) {
        console.log(data)
        if (!err) {
            res.send({
                success: true,
                data
            })
        } else {
            res.send({
                success: false,
                message: "Something went wrong. Please try after sometime"
            })
        }
    });
}

exports.getAllEvents = function (req, res) {
    loadModel.find({}, function (err, data) {
        if (!err) {
            res.send({
                success: true,
                data
            });
        } else {
            res.send({
                success: false,
                message: "Something went wrong. Please try after sometime"
            })
        }
    });
}