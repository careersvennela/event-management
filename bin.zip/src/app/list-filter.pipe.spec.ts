import { ListFilterPipe } from './list-filter.pipe';

describe('ListFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ListFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
